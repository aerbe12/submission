SELECT RegionDescription, FirstName, LastName, hbd

FROM 
(
  
  SELECT RegionId AS RegId, MAX(Employee.Birthdate) AS hbd 
  FROM Employee
    INNER JOIN EmployeeTerritory ON Employee.Id = EmployeeTerritory.EmployeeId
    INNER JOIN Territory ON TerritoryId = Territory.Id
  GROUP BY RegionId

)
INNER JOIN (
            SELECT FirstName, LastName, Birthdate, RegionId, EmployeeId
            FROM Employee
              INNER JOIN EmployeeTerritory ON Employee.Id = EmployeeTerritory.EmployeeId
              INNER JOIN Territory ON TerritoryId = Territory.Id
           )
           ON Birthdate = hbd AND RegId = RegionId

INNER JOIN Region ON Region.Id = RegionId
GROUP BY EmployeeId
ORDER BY RegId;