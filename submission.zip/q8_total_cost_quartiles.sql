WITH expenditures AS (
    
    SELECT
        IFNULL(cus.CompanyName, 'MISSING_NAME') AS ComName,
        ord.CustomerId,
        ROUND(SUM(ordet.Quantity * ordet.UnitPrice), 2) AS TotCost
    
    FROM 'Order' AS ord
    INNER JOIN OrderDetail ordet on ordet.OrderId = ord.Id
    LEFT JOIN Customer cus on cus.Id = ord.CustomerId
    GROUP BY ord.CustomerId
    
),

quartiles AS (
   
    SELECT *, NTILE(4) OVER (ORDER BY TotCost ASC) AS ExpenditureQuartile
    FROM expenditures
)

SELECT ComName, CustomerId, TotCost
FROM quartiles

WHERE ExpenditureQuartile = 1
ORDER BY TotCost ASC;
