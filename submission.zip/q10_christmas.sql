with produk as (
     
      select Product.Id, Product.ProductName as name
      from Product
            inner join OrderDetail on Product.id = OrderDetail.ProductId
            inner join 'Order' on 'Order'.Id = OrderDetail.OrderId
            inner join Customer on CustomerId = Customer.Id
      where DATE(OrderDate) = '2014-12-25' and CompanyName = 'Queen Cozinha'
      group by Product.id
),

company as (
     
      select row_number() over (order by produk.id asc) as seqnum, produk.name as name
      from produk
),

flattened as (
      
      select seqnum, name as name
      from company
      where seqnum = 1
      union all
      select company.seqnum, horizon.name || ', ' || company.name
      from company join
            flattened horizon
            on company.seqnum = horizon.seqnum + 1

)

select name from flattened
order by seqnum desc limit 1;
