SELECT CompanyName, round(hitdelay * 100.0 / hit, 2) AS persen

FROM (
      SELECT ShipVia, COUNT(*) AS  hit
      FROM 'Order'
      GROUP BY ShipVia
     ) AS HitTot

INNER JOIN (
            SELECT ShipVia, COUNT(*) AS HitDelay
            FROM 'Order'
            WHERE ShippedDate > RequiredDate 
            GROUP BY ShipVia
           ) AS HitDelay
          
          ON HitTot.ShipVia = HitDelay.ShipVia

INNER JOIN Shipper on HitTot.ShipVia = Shipper.Id

ORDER BY persen DESC;