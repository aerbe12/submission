SELECT CategoryName

     , COUNT(*) AS HitungCategory
     , ROUND(AVG(UnitPrice), 2) AS RataRataHarga
     , MIN(UnitPrice) AS HargaMin
     , MAX(UnitPrice) AS HargaMax
     , SUM(UnitsOnOrder) AS TotalPesanan

FROM Product INNER JOIN Category on CategoryId = Category.Id

GROUP BY CategoryId

HAVING HitungCategory > 10

ORDER BY CategoryId;
