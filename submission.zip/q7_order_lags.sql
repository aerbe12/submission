SELECT
     
     Id
     , OrderDate
     , SebelumTglOrder
     , ROUND(julianday(OrderDate) - julianday(SebelumTglOrder), 2)

FROM (
    
     SELECT Id
          , OrderDate
          , LAG(OrderDate, 1, OrderDate)
           OVER (ORDER BY OrderDate ASC) AS SebelumTglOrder
     FROM 'Order' 
     WHERE CustomerId = 'BLONP'
     ORDER BY OrderDate ASC
     LIMIT 10

);
